public class переменные {
    public static void main(String[] args) {
        byte b = 127;
        short s = 32767;
        char c = 'c';
        int i = 1233237256;
        long l = 326343678;
        float f = 246666758f;
        double d = 327373273d;

        System.out.println(b);
        System.out.println(s);
        System.out.println(c);
        System.out.println(i);
        System.out.println(l);
        System.out.println(f);
        System.out.println(d);
    }
}
